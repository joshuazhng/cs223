/*
 * Filename: AVLTree.cpp
 * Contains: Implementation of AVL Trees for CPSC 223
 * Part of: Homework assignment "AVL Trees" for CPSC 223
 * Joshua Zhang
 * CPSC 223 PSET 5
 * 4/14/23
 */

#include <iostream>

#include "AVLTree.h"
#include "pretty_print.h"

using namespace std;

/*
 * Input: data (the value to store), multiplicity of the node, height of the
 *      node, left and right child pointers
 * Returns: avl tree node.
 * Does: creates a new node with values given as input parameter
 */
static Node *new_node(int data, int multiplicity, int height, Node *left, Node *right)
{
    Node *node = new Node();

    node->data = data;
    node->count = multiplicity;
    node->height = height;
    node->left = left;
    node->right = right;

    return node;
}

/*
 * Input: data (the value to store)
 * Returns: avl tree node.
 * Does: calls a helper function to create a new node with default
 *        values parameter
 */
static Node *new_node(int data)
{
    return new_node(data, 1, 0, NULL, NULL);
}

/********************************
 * BEGIN PUBLIC AVLTREE SECTION *
 ********************************/

// Constructor
AVLTree::AVLTree()
{
    root = NULL;
}

// Copy Constructor
AVLTree::AVLTree(const AVLTree &source)
{
    root = pre_order_copy(source.root);
}

// Destructor
AVLTree::~AVLTree()
{
    post_order_delete(root);
}

// assignment overload
AVLTree &AVLTree::operator=(const AVLTree &source)
{
    // check for self-assignment
    if (this == &source) {
        return *this; // Return *this to avoid unnecessary work
    }

    // delete current tree if it exists
    post_order_delete(root);

    // use pre-order traversal to copy the tree
    root = pre_order_copy(source.root);

    // don't forget to "return *this"
    return *this;
}

int AVLTree::find_min() const
{
    return find_min(root)->data;
}

int AVLTree::find_max() const
{
    return find_max(root)->data;
}

bool AVLTree::contains(int value) const
{
    return contains(root, value);
}

void AVLTree::insert(int value)
{
    root = insert(root, value);
}

void AVLTree::remove(int value)
{
    root = remove(root, value);
}

int AVLTree::tree_height() const
{
    return tree_height(root);
}

int AVLTree::node_count() const
{
    return node_count(root);
}

int AVLTree::count_total() const
{
    return count_total(root);
}

void AVLTree::print_tree() const
{
    print_pretty(root, 1, 0, std::cout);
}

/*************************
 * BEGIN PRIVATE SECTION *
 *************************/

Node *AVLTree::find_min(Node *node) const
{
    // If the left child of this node is null, the node is the minimum
    if (node->left == NULL) {
        return node;
    }

    // Recursively search in the left subtree
    return find_min(node->left);
}

Node *AVLTree::find_max(Node *node) const
{
    // If the right child of this node is null, the node is the maximum
    if (node->right == NULL) {
        return node;
    }

    // Recursively search in the right subtree
    return find_max(node->right);
}

bool AVLTree::contains(Node *node, int value) const
{
    if (node == NULL) {
        return false;
    }

    if (value < node->data) {
        // If value is less than current node's data, search in left subtree
        return contains(node->left, value);
    } else if (value > node->data) {
        // If value is greater than current node's data, search in right subtree
        return contains(node->right, value);
    } else {
        // Value found at current node
        return true;
    }
}

Node *AVLTree::insert(Node *node, int value)
{
    /* BST insertion start */
    if (node == NULL)
    {
        return new_node(value);
    }
    else if (value < node->data)
    {
        node->left = insert(node->left, value);
    }
    else if (value > node->data)
    {
        node->right = insert(node->right, value);
    }
    else if (value == node->data)
    {
        node->count++;
        return node;
    }
    /* BST insertion ends */

    /* AVL maintenance start */
    node->height = 1 + max(tree_height(node->left), tree_height(node->right));
    node = balance(node);
    /* AVL maintenace end */

    return node;
}

Node *AVLTree::remove(Node *node, int value)
{
    /* BST removal begins */
    if (node == NULL)
    {
        return NULL;
    }

    Node *root = node;
    if (value < node->data)
    {
        node->left = remove(node->left, value);
    }
    else if (value > node->data)
    {
        node->right = remove(node->right, value);
    }
    else
    {
        // We found the value. Remove it.
        if (node->count > 1)
        {
            node->count--;
        }
        else
        {
            if (node->left == NULL && node->right == NULL)
            {
                root = NULL;
                delete node;
                return root;
            }
            else if (node->left != NULL && node->right == NULL)
            {
                root = node->left;
                node->left = NULL;
                delete node;
            }
            else if (node->left == NULL && node->right != NULL)
            {
                root = node->right;
                node->right = NULL;
                delete node;
            }
            else
            {
                Node *replacement = find_min(node->right);
                root->data = replacement->data;
                root->count = replacement->count;
                replacement->count = 1;
                root->right = remove(root->right, replacement->data);
            }
        }
    }
    /* BST removal ends */

    /* AVL maintenance begins */
    if (root != NULL)
    {
        root->height = 1 + max(tree_height(root->left), tree_height(root->right));
        root = balance(root);
    }
    /* AVL maintenance ends */

    return root;
}

int AVLTree::tree_height(Node *node) const
{
    if (node == NULL) {
        // If the node is null, we have reached the end of the tree and the height is 0
        return 0;
    }
    return node->height;
}

int AVLTree::node_count(Node *node) const
{
    if (node == NULL) {
        return 0;
    }
    return 1 + node_count(node->left) + node_count(node->right);
}

int AVLTree::count_total(Node *node) const
{
    if (node == NULL) {
        return 0;
    }
    return (node->count * node->data) + count_total(node->left) + count_total(node->right);
}

Node *AVLTree::pre_order_copy(Node *node) const
{
    if (node == NULL)
    {
        return NULL;
    }
    Node *new_node = new Node();

    new_node->data = node->data;
    new_node->height = node->height;
    new_node->count = node->count;
    new_node->left = pre_order_copy(node->left);
    new_node->right = pre_order_copy(node->right);

    return new_node;
}

void AVLTree::post_order_delete(Node *node)
{
    if (node == NULL) {
        return;
    }

    post_order_delete(node->left);
    post_order_delete(node->right);
    delete node;
}

Node *AVLTree::balance(Node *node)
{
    if (node == NULL) {
        return NULL;
    }

    // Update height of node
    int leftHeight = node->left ? node->left->height : 0;
    int rightHeight = node->right ? node->right->height : 0;
    node->height = 1 + max(leftHeight, rightHeight);

    // Check balance factor to see if left or right subtree is taller 
    int balanceFactor = leftHeight - rightHeight;
    if (balanceFactor > 1) {
        if (height_diff(node->left) >= 0) {
            // Left-Left case, perform right rotation
            return right_rotate(node);
        } else {
            // Left-Right case, perform left rotation on left child
            node->left = left_rotate(node->left);
            return right_rotate(node);
        }
    } else if (balanceFactor < -1) {
        if (height_diff(node->right) <= 0) {
            // Right-Right case, perform left rotation
            return left_rotate(node);
        } else {
            // Right-Left case, perform right rotation on right child
            node->right = right_rotate(node->right);
            return left_rotate(node);
        }
    }

    return node; // Tree is balanced
}

Node *AVLTree::right_rotate(Node *node)
{
    Node *new_root = node->left;
    node->left = new_root->right;
    new_root->right = node;

    // Update heights
    node->height = 1 + max(height_diff(node->left), height_diff(node->right));
    new_root->height = 1 + max(height_diff(new_root->left), height_diff(new_root->right));

    return new_root;
}

Node *AVLTree::left_rotate(Node *node)
{
    Node *new_root = node->right;
    node->right = new_root->left;
    new_root->left = node;

    // Update heights
    node->height = 1 + max(height_diff(node->left), height_diff(node->right));
    new_root->height = 1 + max(height_diff(new_root->left), height_diff(new_root->right));

    return new_root;
}

int AVLTree::height_diff(Node *node) const
{
    if (node == NULL) {
        return 0;
    }

    int left_height = tree_height(node->left);
    int right_height = tree_height(node->right);
    int height_difference = left_height - right_height;
    return height_difference;
}

Node *AVLTree::find_parent(Node *node, Node *child) const
{
    if (node == NULL)
        return NULL;

    // if either the left or right is equal to the child,
    // we have found the parent
    if (node->left == child or node->right == child)
    {
        return node;
    }

    // Use the binary search tree invariant to walk the tree
    if (child->data > node->data)
    {
        return find_parent(node->right, child);
    }
    else
    {
        return find_parent(node->left, child);
    }
}
